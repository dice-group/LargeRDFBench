#!/bin/bash

if [ "$#" -lt 5 ]; then
    echo "Usage: $0 [query_file] [endpoints_description] [heuristic] [result_file] [errors_files]"
    exit 1
fi

(timeout -s 12 20m python /home/saleem/anapsid/scripts/run_anapsid -e $2 -q $1 -p b -s False -b 16384 -o False -d $3 -a True) #2>> $5 >> $4;
