sparql_desc="/home/saleem/anapsid/scripts/endpointsDescriptions.txt"
run_anap="/home/saleem/anapsid/scripts/run_anapsid"
heuristics="SSGM"

echo python $run_anap -e $sparql_desc -q $0 -p b -s False -b 16384 -o False -d $heuristics -a True
