./runQueries.sh ../queries/fedBench ../scripts/endpointsDescriptions.txt SSGM output_file error_file
